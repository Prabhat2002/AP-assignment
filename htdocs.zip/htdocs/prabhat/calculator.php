<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form>
          <input  type="text"  name="num1" placeholder="first number">
          <br>
          <input  type="text"  name="num2" placeholder="second number">
          <select name="operator">
              <option>None</option>
              <option>add</option>
              <option>sub</option>
              <option>multiply</option>
              <option>div</option>
          </select>
          <br>
          <button value="submit" type="submit" name="submit">calculate</button>
        </form>

    <?php
      if($_GET['submit'])
      {
        $a=$_GET['num1'];
        $b=$_GET['num2'];
        $operation=$_GET['operator'];
        switch($operation)
        {
            case None:
            {
              print "You are not selecting anyone";
              break;
            }
            case add:
            {
                print "Addition=".($a+$b);
                break;
            }
            case sub:
            {
                print "Substraction=".($a-$b);
                break;
            }
            case multiply:
            {
                print "Multiplication=\n".($a*$b);
                break;
            }
            case div:
            {
                print "Division=\n".($a/$b);
                break;
            }                                                
        }
      }
    ?>
</body>
</html>