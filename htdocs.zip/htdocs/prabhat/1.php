<?php
if (date('G') < 12) {
    $greeting = 'Good Morning!';
} else {
    $greeting = 'Welcome!';
}
?>

<html>
<head>
<title>Welcome to Our Web Site</title>
</head>
<body>

<h1><?php echo $greeting; ?></h1>

<p>Outside Declration</p>

</body>
</html>
