<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Array in PHP</title>
</head>
<body>
<?php
   $names=array("Hello","Everyone","Whats","UP");
   echo $names[1];//print Everyone
   echo $names['1'];//print Everyone
   //echo $names['5'];//ERROR OF UNDEFINED CONTENT
   $names=array(3,5,1,6);
   echo $names[1];
   echo $names['1'];
   $names=array(3,"network",1,6);
   echo $names[0];// print 3
   echo $names['1'];// print network
   echo $names[1][2];// print 't' from network
?>
</body>
</html>