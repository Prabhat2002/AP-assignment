<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <form method="GET">
    Enter First Number:-<input type="number" name="person1">
    Enter Second Number:-<input type="number" name="person2">
    <button  name="btn">find</button>
   </form> 
   <?php
       $a=$_GET['person1'];
       $b=$_GET['person2'];
       $btn=$_GET['btn'];
       for($i=$a;$i<=$b;$i=$i+1)
       {
           $p=0;
           for($j=2;$j<$i;$j++)
           {
               if($i%$j==0)
               {
                   $p++;
               }
           }
           if($p==0)
           {
               echo $i;
               echo " ";
           }
       }   
  ?>
</body>
</html>