<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" type="text/css" href="compact.css">
</head>
<body>
    
    <?php
         $numday=date("w");
         echo $numday;
         //if we want to add css you should put that tag inside the echo.
         echo"<p>this is sunday!</p>"; 
    ?>

</body>
</html>