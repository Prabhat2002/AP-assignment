<html>
<head>
    <style>
      input
      {
          color:blue;
          background-color: rgba(1,0,250,0.4);
          border:2px solid rgb(254,7,2);
      } 
      button
      {
          background:yellow;
      }    
      form 
      {
             border:3px solid rgb(200,200,200);
             background-color:rgba(70,20,250,0.7);
             padding:10px;
             width:200px;
             margin:auto;
      }
    </style>
</head>
<body>
Welcome 
<?php 
  echo $_POST["name"]; 
?>
Your email address is: '+'
<?php 
  echo $_POST["email"]; 
?>
<br><br>
<form>
    <input type="text" name="name" placeholder="enter youe good name">
    <br>
    <br>
    <input type="email" name="email" placeholder="enter your email">
    <br>
    <br>
    <button>submit</button>
</form>
<br>
</body>
</html>
