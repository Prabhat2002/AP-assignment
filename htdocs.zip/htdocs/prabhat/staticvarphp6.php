<html>
<head>
<title>Welcome to Our Web Site</title>
</head>
<body>
  <?php
     function keep_track()
    {
        $count = 0;
        $count++;
        print $count;
        print "<br/>";
     }
     keep_track();
     keep_track();
     keep_track();
  ?>
</body>
</html>
