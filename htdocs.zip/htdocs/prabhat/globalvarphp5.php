<html>
<head>
<title>Welcome to Our Web Site</title>
</head>
<body>
<?php
 //  GLOBAL $somevar = 15;

   $x=90;
   function addit()
   {
     echo $GLOBALS['x'];
   }
   addit();
?>
</body>
</html>
