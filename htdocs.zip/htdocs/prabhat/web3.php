<?php
   if( $_POST["location"] ) {
      $location = $_POST["location"];
      header( "Location:$location" );

      exit();
   }
?>
<html>
   <body>

      <p>Choose a site to visit :</p>

      <form action = "<?php $_SERVER['PHP_SELF'] ?>" method ="POST">
         <select name = "location">.

            <option value = "http://www.jmi.ac.in">
               JAMIA MILLIA ISLAMIA
            </option>

            <option value = "http://www.iiitsonepat.ac.in">
               IIIT SONEPAT
            </option>

            <option value = "http://www.iitdelhi.ac.in">
               IIT DELHI
            </option>

            <option value = "http://www.iiitallahabad.ac.in">
               IIIT ALLAHABAD
            </option>
         </select>
         <input type = "submit" />
      </form>

   </body>
</html>
