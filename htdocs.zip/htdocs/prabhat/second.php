<html>
<head>
<title>Welcome to Our Web Site</title>
</head>
<body>
  <?php
   // multiply a value by 10 and return it to the caller
   function intro()
   {
      $name="Ravi Mishra";
      $age=19;
      echo "name is $name ";
      echo "age is $age";
   }
?>
</body>
</html>
