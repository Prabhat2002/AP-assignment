<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="GET">
    <input type="number" name="person">
    <button>find</button>
</form>
 <?php
   $i=$_GET['person'];
   $p=0;
       for($x=1;$x<=$i;$x++)
       {
           if($i%$x==0)
           {
               $p++;
           }
       }
       if($p==2)
       {
           echo $i." is a Prime Number";
       }
       else
       {
        echo $i."is a Non Prime Number";
       }
 ?>
</body>
</html>