<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    // $name="Ravi Mishra";
    //  echo $name." is a handsome guy"; 
    $name1="RAVI";
    $name2="MISHRA";
    echo $name1.$name2;
    ?>
</body>
</html>