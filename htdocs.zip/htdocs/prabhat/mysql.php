<?php
  echo "WELCOME TO THE STAGE WHERE WE ARE READY TO GET CONNECTED TO A DATABASE";
  $servername="localhost";
  $username="root";
  $password="";
  $database="SONEPAT";
  $con=mysqli_connect($servername,$username,$password,$database);
 
  if(!$con)
  {
      die("FAILED TO CONNECT DUE TO ERROR".mysqli_connect_error());
  }
  else
  {
       echo "<br> Server Created";
  }
  $sql="INSERT INTO `login` (`ID`, `NAME`, `ROLL NO:`, `E-MAIL`, `BRANCH`, `COLLEGE`, `SKILL`) VALUES ('19', 'garv singal', '11911070', 'codergrav22@gmail.com', 'CSE', 'IIITS', 'PYTHON  PERL');";
 // $sql="CREATE TABLE `login`(`ID` INT(8) NOT NULL AUTO_INCREMENT,`NAME` VARCHAR(20) NOT NULL,`ROLL NO:` INT(8) NOT NULL,`E-MAIL` VARCHAR(100) NOT NULL, `BRANCH` VARCHAR(40) NOT NULL,`COLLEGE` VARCHAR(100) NOT NULL,`SKILL` VARCHAR(100) NOT NULL,PRIMARY KEY(`ID`))";
  $RESULT=mysqli_query($con,$sql);
  if($RESULT)
  {
     echo "inserted SUCCESSFULLY!!";
  }
  else
  {
    echo "<br>error".mysqli_error($con);
  }
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>