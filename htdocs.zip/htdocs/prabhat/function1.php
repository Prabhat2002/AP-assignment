<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hi function of PHP</title>
</head>
<body>
    <?php
      echo strlen("HELLO PRABHAT");// lenght of string 
      echo str_word_count("hello prabhat");// words in the string
      echo strrev("malang\n");// reversing string
      echo strpos("Hello prabhat mishra","Hello");//initial position of string '0'
      echo strpos("Hello prabhat mishra","prabhat");//initial position of string '6'
      echo strpos("Hello prabhat mishra","xyz");
      echo str_replace("HELLO","HI","HELLO PRABHAT");// Replacing "HELLO" from "HI"
    ?>
</body>
</html>