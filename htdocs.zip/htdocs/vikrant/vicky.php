<html>
<head>
<title>Welcome to Our Web Site</title>
</head>
<body>

<h1>
<?php
print "This is Vikrant judge of CSE 11911016"
?>
</h1>

<p>This is start of PHP( inside declration)</p>

</body>
</html>
