<?php
    include_once 'includes/database connectivity.php';
?>  
<!DOCTYPE html>
<html lang="en">
<head>  
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
   <?php
         $sql="select * from registration;";
         $result=mysqli_query( $con,$sql);
         $resultcheck=mysqli_num_rows($result);
         if($resultcheck>0)
         {
             while($row=mysqli_fetch_assoc($result))
             {
                echo $row['user_uid'];
             }
         }
?>
</body>
</html>